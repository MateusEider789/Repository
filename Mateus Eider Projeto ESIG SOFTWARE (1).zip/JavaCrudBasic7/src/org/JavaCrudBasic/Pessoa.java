package org.JavaCrudBasic;

public class Pessoa {
	
	
	private long id;
	private String nome;
	private String apelido;
	private String idade;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getApelido() {
		return apelido;
	}
	public void setApelido(String apelido) {
		this.apelido = apelido;
	}
	public String getIdade() {
		return idade;
	}
	public void setIdade(String string) {
		this.idade = string;
	}
	public Pessoa() {
		super();
	}
	

}
