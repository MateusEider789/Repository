import java.util.ArrayList;


import java.util.List;

import org.JavaCrudBasic.Pessoa;

import Repositorio.RepositorioPessoa;

public static void main(String [] args) {
	
	popularArray();
	listarPessoas();
	rp.alterar               PessoaPorId(1);
	listarPessoas();
	
	
}

public static void alterar() {
	 	Pessoa pessoa = new Pessoa();
		pessoa.setApelido("Eider");
		pessoa.setId(1);
		pessoa.setIdade("31");
		pessoa.setNome("Mateus Marcos");
		rp.alterarPessoa(pessoa);
	
	
}

public class Teste {

	public  static void popularArray() {
	 Pessoa pessoa = new Pessoa();
		pessoa.setApelido("Teus");
		pessoa.setId(1);
		pessoa.setIdade("30");
		pessoa.setNome("Mateus");
		
		pessoa.setApelido("Samuca");
		pessoa.setId(1);
		pessoa.setIdade("22");
		pessoa.setNome("Samuel");
		pessoa.setApelido("Gabi");
		pessoa.setId(1);
		pessoa.setIdade("20");
		pessoa.setNome("Gabriela");
		
		
		
	 
 }
		
 public void lista(){
	 		List<Pessoa> lista = new ArrayList<Pessoa>();
        	RepositorioPessoa rp = new RepositorioPessoa();
        	
        	List<Pessoa> listarPessoa = (List<Pessoa>) rp.listarPessoa();
			List<Pessoa> listarPessoa2 = listarPessoa;
			List<Pessoa> listarPessoa1 = listarPessoa2;
			lista = listarPessoa1;
        			
        	for (Pessoa pessoa1 : lista) {
        				
        			System.out.println(pessoa1.getId());
        			System.out.println(pessoa1.getNome());
        			System.out.println(pessoa1.getApelido());
        			System.out.println(pessoa1.getIdade());
        			}
					}

}
