package Repositorio;

import java.util.ArrayList;
import java.util.List;

import org.JavaCrudBasic.Pessoa;


public class RepositorioPessoa implements IRepositorioPessoa {
	
	List<Pessoa> listaPessoas = new ArrayList<Pessoa>();
	
	

	@Override
		public boolean salvaPessoa(Pessoa pessoa) {
		
		try {
			
		} catch (Exception e) {
			return false;
		}
		return true;
		
	}

	@Override
	public boolean deletarPessoaPorID(long id) {
		for (Pessoa pessoa : listaPessoas) {
			if (pessoa.getId() == id) {
				List<Pessoa> listarPessoas = null;
				listarPessoas.remove(pessoa);
			}
		}
		
		return false;
	}

	@Override
	public List<Pessoa> listarPessoa1() {
		return listaPessoas;
	}

	@Override
	public boolean alterarPessoa(Pessoa Pessoa) {
	
		for (Pessoa pessoa : listaPessoas) {
			long id = 0;
			if (pessoa.getId() == id) {
				listaPessoas.remove(pessoa);
				listaPessoas.add(pessoa);
			}
		}
		return false;
	}

	@Override
	public java.awt.List listarPessoa() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean salvaPessoa1(Pessoa pessoa) {
		// TODO Auto-generated method stub
		return false;
	}

}
