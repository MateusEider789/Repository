package Repositorio;

public class listaPessoas {

	public void setId(long id) {
		// TODO Auto-generated method stub
		
	}

}
