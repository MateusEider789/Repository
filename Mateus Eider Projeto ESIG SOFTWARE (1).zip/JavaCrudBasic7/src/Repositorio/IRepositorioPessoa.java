package Repositorio;

import java.awt.List;

import org.JavaCrudBasic.Pessoa;

public interface IRepositorioPessoa {

	
	
	public boolean salvaPessoa(Pessoa pessoa);
	public boolean deletarPessoaPorID(long id);
	public List listarPessoa();
	public boolean alterarPessoa(Pessoa Pessoa);
	boolean salvaPessoa1(Pessoa pessoa);
	java.util.List<Pessoa> listarPessoa1();
	
}
